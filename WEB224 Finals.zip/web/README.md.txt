Green Juniors Fruits and Vegetables:

1.) Install packages required by the project (if not already installed), (express, cors, and node-fetch)

2.) Run the server using the terminal by typing, "node server.js"

3.) To check the functionality of the API which works with the help of the WebSocket you can search this in your browser's search bar to check: (http://localhost:6253/api/fruit/[your fruit]) 
Note: You'll need to start the server.js in order to properly use the page (the API depends on the WebSocket connection)