document.addEventListener('DOMContentLoaded', async () => {
    try {
        const country = await getLocation();
        document.getElementById('country').textContent = `Country: ${country}`;
    } catch (error) {
        console.error('Error fetching location data:', error);
    }

    document.querySelector('button').addEventListener('click', fruitSearch);
});

async function fruitSearch() {
    const fruitName = document.getElementById('fruit_name').value;
    if (!fruitName) return;

    try {
        const response = await fetch(`http://localhost:6253/api/fruit/${fruitName}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        fruitInfo(data);
    } catch (error) {
        console.error('Error fetching fruit data:', error);
        document.getElementById('fruit_found').style.display = 'none';
        document.getElementById('fruit_not_found').style.display = 'block';
    }
}

function fruitInfo(data) {
    const genusList = document.getElementById('genus_list');
    const orderList = document.getElementById('order_list');
    const familyList = document.getElementById('family_list');
    const caloriesList = document.getElementById('calories_list');

    if (genusList && orderList && familyList && caloriesList) {
        genusList.textContent = `Genus: ${data.genus}`;
        orderList.textContent = `Order: ${data.order}`;
        familyList.textContent = `Family: ${data.family}`;
        caloriesList.textContent = `Calories: ${data.nutritions.calories}`;

        document.getElementById('fruit_found').style.display = 'block';
        document.getElementById('fruit_not_found').style.display = 'none';
    } else {
        console.error('Required elements are missing from the DOM.');
    }
}

async function getLocation() {
    try {
        const response = await fetch('http://ip-api.com/json/?fields=country,regionName,city');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        return `${data.country}, ${data.regionName}, ${data.city}`;
    } catch (error) {
        console.error('Error fetching country data:', error);
        throw error;
    }
}
