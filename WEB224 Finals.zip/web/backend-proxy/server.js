const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
const PORT = process.env.PORT || 6253;

app.use(cors());
app.use(express.json());

app.get('/api/fruit/:name', async (req, res) => {
    try {
        const { name } = req.params;
        const response = await fetch(`https://www.fruityvice.com/api/fruit/${name}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error('Error fetching fruit:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/user-location', async (req, res) => {
    try {
        const response = await fetch('https://ipapi.com/json/');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        res.json({ country: data.country_name });
    } catch (error) {
        console.error('Error fetching location:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
